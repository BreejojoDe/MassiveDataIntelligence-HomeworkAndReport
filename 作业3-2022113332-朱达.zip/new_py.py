import jieba
from wordcloud import WordCloud
from collections import Counter
from LAC import LAC
import matplotlib.pyplot as plt

def load_stopwords(stopwords_dir):
    stopwords = []
    with open(stopwords_dir, "r", encoding="utf8") as file:
        for line in file.readlines():
            stopwords.append(line.strip())
    return stopwords

def count_elements_stop(lst, stopwords):
    count_dict = {}
    for element in lst:
        if element in stopwords:
            continue
        if element in count_dict:
            count_dict[element] += 1
        else:
            count_dict[element] = 1
    return count_dict

def find_top_words(file_name, stops):
    with open(file_name, 'r', encoding='utf8') as file:
        text = file.read()
        text = text.replace('\n', '')
        words = jieba.lcut(text)
        words = count_elements_stop(words, stops)
        top_words = []
        for key, value in Counter(words).most_common(100):
            top_words.append(key)
        return words, top_words

def calc_frequency(dict, list_key):
    frequencies = {}
    for key in list_key:
        frequencies[key] = dict[key] if key in dict else 0
    return frequencies

stops = load_stopwords('stopwords.txt')

words20, top_words20 = find_top_words('二十大报告.txt', stops)
words19, _ = find_top_words('十九大报告.txt', stops)

intersection = list(set(words20.keys()) - set(words19.keys()))

frequencies = calc_frequency(words20, intersection)

wordcloud = WordCloud(width=800, height=400, font_path="STSONG.TTF").fit_words(frequencies)
fig = plt.figure(figsize=(10, 5), dpi=100)
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis("off")
plt.show()

with open('二十大报告.txt', 'r', encoding='utf8') as file:
    text = file.read()
    text = text.replace('\n', '')
    lac = LAC(mode='lac')
    lac_result = lac.run(text)
    ner_tag=['PER','LOC','ORG']
    result={}
    for (i, tag) in enumerate(lac_result[1]):
        if tag in ner_tag:
            if lac_result[0][i] in result:
                result[lac_result[0][i]] += 1
            else:
                result[lac_result[0][i]] = 1
    print(result)
