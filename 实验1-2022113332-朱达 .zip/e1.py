import requests
from bs4 import BeautifulSoup

url = "http://www.hgrd.gov.cn/html/2022-10-17/3445.html"
response = requests.get(url)
response.encoding="utf-8"
html_content = response.text
soup = BeautifulSoup(html_content, 'html.parser')
content = soup.find(id="endtext").getText()
print(content)